<?php

/**
 * @file sendgrid_integration_reports.api.php
 * Hooks provided by the Sendgrid Integration Reports module.
 */

/**
 * @addtogroup hooks
 * @{
 */
